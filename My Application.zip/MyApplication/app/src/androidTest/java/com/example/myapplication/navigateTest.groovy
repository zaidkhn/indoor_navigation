package com.example.myapplication

class navigateTest extends groovy.util.GroovyTestCase {
}
